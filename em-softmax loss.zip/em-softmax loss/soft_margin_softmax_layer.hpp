#ifndef CAFFE_SOFT_MARGIN_SOFTMAX_LAYER_HPP_
#define CAFFE_SOFT_MARGIN_SOFTMAX_LAYER_HPP_

#include <vector>

#include "caffe/blob.hpp"
#include "caffe/layer.hpp"
#include "caffe/proto/caffe.pb.h"

namespace caffe {

	/**
	* @brief Computes the soft margin softmax function.
	*
	* Ensemble Soft-Margin Softmax Loss for Image Classification, Xiaobo Wang etc. Submitted to CVPR, 2018
	* This layer contains parameters!!! It contains 2 phase, inner product phase, and 
	* TODO(dox): thorough documentation for Forward, Backward, and proto params.
	*/
	template <typename Dtype>
	class SoftMarginSoftmaxLayer : public Layer<Dtype> {
	public:
		explicit SoftMarginSoftmaxLayer(const LayerParameter& param)
			: Layer<Dtype>(param) {}
		virtual void LayerSetUp(const vector<Blob<Dtype>*>& bottom,
			const vector<Blob<Dtype>*>& top);
		virtual void Reshape(const vector<Blob<Dtype>*>& bottom,
			const vector<Blob<Dtype>*>& top);
		virtual inline const char* type() const { return "SoftMarginSoftmax"; }
		//virtual inline int MinNumBottomBlobs() const { return 1; }
		virtual inline int ExactNumBottomBlobs() const { return 2; }
		virtual inline int ExactNumTopBlobs() const { return 1; }

	protected:
		virtual void Forward_cpu(const vector<Blob<Dtype>*>& bottom,
			const vector<Blob<Dtype>*>& top);
//		virtual void Forward_gpu(const vector<Blob<Dtype>*>& bottom,
//			const vector<Blob<Dtype>*>& top);
		virtual void Backward_cpu(const vector<Blob<Dtype>*>& top,
			const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom);
//		virtual void Backward_gpu(const vector<Blob<Dtype>*>& top,
//			const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom);
		Blob<Dtype> sum_multiplier_;
		Blob<Dtype> scale_;

		int soft_margin_softmax_axis_;

		//modified by xiaobo wang
		int outer_num_;
		int inner_num_;
	};

}  // namespace caffe

#endif  // CAFFE_SOFT_MARGIN_SOFTMAX_LAYER_HPP_
