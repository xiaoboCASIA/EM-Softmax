#include <algorithm>
#include <cfloat>
#include <vector>

#include "caffe/layers/ensemble_softmax_loss_layer.hpp"
#include "caffe/util/math_functions.hpp"

namespace caffe {

template <typename Dtype>
void EnsembleSoftmaxLossLayer<Dtype>::LayerSetUp(
    const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {
  LossLayer<Dtype>::LayerSetUp(bottom, top);
  LayerParameter softmax_param(this->layer_param_);
//  softmax_param.set_type("Softmax");

  //to obtain the softmax_type
  string layer_type = this->layer_param_.loss_param().softmax_type();
  if (layer_type != "Softmax" && layer_type != "SoftMarginSoftmax")
  {
  	LOG(FATAL) << "SoftmaxWithLossLayer can only support Softmax and SoftMarginSoftmax";
  }
  softmax_param.set_type(layer_type);
  softmax_layer_ = LayerRegistry<Dtype>::CreateLayer(softmax_param);

  ///////////////////New Layer (K and WHW)//////////////////////////////////
  ensemble_num_ = (bottom.size() - 1)/2;
  lamda_ = this->layer_param_.ensemble_softmax_loss_param().lamda();
  num_in_ = bottom[ensemble_num_]->shape(1);
  num_out_ = bottom[ensemble_num_]->shape(0);
  /// initialize the probs
  probs_.resize(ensemble_num_);
  for(int i=0;i<ensemble_num_;i++){
	  probs_[i].reset(new Blob<Dtype>(bottom[0]->shape()));
  }
  /// Reshape the WH_ and WHW_
  WK_.Reshape(num_in_,num_out_,1,1);
  WKW_.Reshape(num_in_,num_in_,1,1);
  /// Reshape and initialize the H_
  H_.Reshape(num_out_,num_out_,1,1);
  caffe_set(num_out_*num_out_, (Dtype)(-1.0/num_out_), H_.mutable_cpu_data());
  for(int i=0;i<num_out_;i++){
	  for(int j=0;j<num_out_;j++){
		  if(i==j){
			  H_.mutable_cpu_data()[i*num_out_+j]=H_.cpu_data()[i*num_out_+j]+1;
		  }
	  }
  }
  /// initialize the K_
  K_.resize(ensemble_num_);
  for(int i=0;i<ensemble_num_;i++){
	  K_[i].reset(new Blob<Dtype>(H_.shape()));
  }
  ///////////////////////New Layer/////////////////////////////

  softmax_bottom_vec_.clear();
  softmax_bottom_vec_.push_back(bottom[0]);

  // to obtain the groundtruth label for SoftMarginSoftmax function
  if (layer_type=="SoftMarginSoftmax")
  {
	  softmax_bottom_vec_.push_back(bottom[ensemble_num_*2]);
  }

  softmax_top_vec_.clear();
  softmax_top_vec_.push_back(&prob_);
  softmax_layer_->SetUp(softmax_bottom_vec_, softmax_top_vec_);
  has_ignore_label_ =
    this->layer_param_.loss_param().has_ignore_label();
  if (has_ignore_label_) {
    ignore_label_ = this->layer_param_.loss_param().ignore_label();
  }
  if (!this->layer_param_.loss_param().has_normalization() &&
      this->layer_param_.loss_param().has_normalize()) {
    normalization_ = this->layer_param_.loss_param().normalize() ?
                     LossParameter_NormalizationMode_VALID :
                     LossParameter_NormalizationMode_BATCH_SIZE;
  } else {
    normalization_ = this->layer_param_.loss_param().normalization();
  }
}

template <typename Dtype>
void EnsembleSoftmaxLossLayer<Dtype>::Reshape(
    const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {
  LossLayer<Dtype>::Reshape(bottom, top);
  softmax_layer_->Reshape(softmax_bottom_vec_, softmax_top_vec_);
  softmax_axis_ =
      bottom[0]->CanonicalAxisIndex(this->layer_param_.softmax_param().axis());
  outer_num_ = bottom[0]->count(0, softmax_axis_);
  inner_num_ = bottom[0]->count(softmax_axis_ + 1);
  CHECK_EQ(outer_num_ * inner_num_, bottom[ensemble_num_*2]->count())
      << "Number of labels must match number of predictions; "
      << "e.g., if softmax axis == 1 and prediction shape is (N, C, H, W), "
      << "label count (number of labels) must be N*H*W, "
      << "with integer values in {0, 1, ..., C-1}.";
  if (top.size() >= 2) {
    // softmax output
    top[1]->ReshapeLike(*bottom[0]);
  }
}

template <typename Dtype>
Dtype EnsembleSoftmaxLossLayer<Dtype>::get_normalizer(
    LossParameter_NormalizationMode normalization_mode, int valid_count) {
  Dtype normalizer;
  switch (normalization_mode) {
    case LossParameter_NormalizationMode_FULL:
      normalizer = Dtype(outer_num_ * inner_num_);
      break;
    case LossParameter_NormalizationMode_VALID:
      if (valid_count == -1) {
        normalizer = Dtype(outer_num_ * inner_num_);
      } else {
        normalizer = Dtype(valid_count);
      }
      break;
    case LossParameter_NormalizationMode_BATCH_SIZE:
      normalizer = Dtype(outer_num_);
      break;
    case LossParameter_NormalizationMode_NONE:
      normalizer = Dtype(1);
      break;
    default:
      LOG(FATAL) << "Unknown normalization mode: "
          << LossParameter_NormalizationMode_Name(normalization_mode);
  }
  // Some users will have no labels for some examples in order to 'turn off' a
  // particular loss in a multi-task setup. The max prevents NaNs in that case.
  return std::max(Dtype(1.0), normalizer);
}

template <typename Dtype>
void EnsembleSoftmaxLossLayer<Dtype>::Forward_cpu(
    const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {
  // The forward pass computes the softmax prob values.
  const Dtype* label = bottom[ensemble_num_*2]->cpu_data();

  for (int i=0;i<ensemble_num_;i++){
	  softmax_bottom_vec_.clear();
	  softmax_bottom_vec_.push_back(bottom[i]);

//	  softmax_bottom_vec_.push_back(bottom[ensemble_num_*2]);

	  softmax_top_vec_.clear();
	  softmax_top_vec_.push_back(&prob_);
	  softmax_layer_->Forward(softmax_bottom_vec_, softmax_top_vec_);
	  probs_[i]->CopyFrom(prob_,false,true);
  }

  // compute K
  for(int i=0;i<ensemble_num_;i++){
  	  caffe_set(num_out_*num_out_, (Dtype)0.0, K_[i]->mutable_cpu_data());
  	  for(int j=0;j<ensemble_num_;j++){
  		  if(i!=j){
  			  caffe_cpu_gemm(CblasNoTrans, CblasTrans,
  					  num_out_, num_out_, num_in_,
  					  (Dtype)1., bottom[ensemble_num_+j]->cpu_data(), bottom[ensemble_num_+j]->cpu_data(),
  					  (Dtype)1., K_[i]->mutable_cpu_data());
  		  }
  	  }
  	  Blob<Dtype> TEMP;
  	  TEMP.Reshape(K_[i]->shape());
  	  caffe_cpu_gemm(CblasNoTrans,CblasNoTrans,
  			  num_out_,num_out_,num_out_,
  			  (Dtype)1., H_.cpu_data(), K_[i]->cpu_data(),
  			  (Dtype)0., TEMP.mutable_cpu_data());
  	  caffe_cpu_gemm(CblasNoTrans,CblasNoTrans,
  			  num_out_,num_out_,num_out_,
  	  			  (Dtype)1., TEMP.cpu_data(), H_.cpu_data(),
  	  			  (Dtype)0., K_[i]->mutable_cpu_data());
  }

  int dim = prob_.count() / outer_num_;
  Dtype loss_sum = (Dtype)0.0;
  for(int en=0;en<ensemble_num_;en++){
	  int count = 0;
	  Dtype softmax_loss = (Dtype)0.;
	  Dtype weight_loss = (Dtype)0.;
	  //softmax_loss
	  for (int i = 0; i < outer_num_; ++i) {
		for (int j = 0; j < inner_num_; j++) {
		  const int label_value = static_cast<int>(label[i * inner_num_ + j]);
		  if (has_ignore_label_ && label_value == ignore_label_) {
			continue;
		  }
		  DCHECK_GE(label_value, 0);
		  DCHECK_LT(label_value, probs_[en]->shape(softmax_axis_));
		  softmax_loss -= log(std::max(probs_[en]->cpu_data()[i * dim + label_value * inner_num_ + j],
							   Dtype(FLT_MIN)));
		  ++count;
		}
	  }
	  // 1/m normalized, m is the batch size.
	  softmax_loss = softmax_loss / get_normalizer(normalization_, count);
	  //weight_loss
	  caffe_cpu_gemm(CblasTrans,CblasNoTrans,
			  num_in_,num_out_,num_out_,
			  (Dtype)1., bottom[ensemble_num_+en]->cpu_data(), K_[en]->cpu_data(),
			  (Dtype)0., WK_.mutable_cpu_data());
	  caffe_cpu_gemm(CblasNoTrans,CblasNoTrans,
			  num_in_,num_in_,num_out_,
			  (Dtype)1., WK_.cpu_data(), bottom[ensemble_num_+en]->cpu_data(),
			  (Dtype)0., WKW_.mutable_cpu_data());
	  for(int i=0;i<num_in_;i++){
		  for(int j=0;j<num_in_;j++){
			  if(i==j){
				  weight_loss += WKW_.cpu_data()[i*num_in_+j];
			  }
		  }
	  }
	  loss_sum = loss_sum + (softmax_loss + 0.5*lamda_ * weight_loss);
  }
  top[0]->mutable_cpu_data()[0] = loss_sum / ensemble_num_;
  if (top.size() == 2) {
    top[1]->ShareData(prob_);
  }
}

template <typename Dtype>
void EnsembleSoftmaxLossLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
    const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom) {
  if (propagate_down[ensemble_num_*2]) {
    LOG(FATAL) << this->type()
               << " Layer cannot backpropagate to label inputs.";
  }
  //compute diff of softmax_loss to z1...zn
  const Dtype* label = bottom[ensemble_num_*2]->cpu_data();
  for(int en=0;en<ensemble_num_;en++){
	  if(propagate_down[en]){
		  Dtype* bottom_diff = bottom[en]->mutable_cpu_diff();
		  const Dtype* prob_data = probs_[en]->cpu_data();
		  caffe_copy(probs_[en]->count(), prob_data, bottom_diff);
		  int dim = probs_[en]->count() / outer_num_;
		  int count = 0;
		  for (int i = 0; i < outer_num_; ++i) {
		    for (int j = 0; j < inner_num_; ++j) {
		      const int label_value = static_cast<int>(label[i * inner_num_ + j]);
		      if (has_ignore_label_ && label_value == ignore_label_) {
		        for (int c = 0; c < bottom[0]->shape(softmax_axis_); ++c) {
		          bottom_diff[i * dim + c * inner_num_ + j] = 0;
		        }
		      } else {
		        bottom_diff[i * dim + label_value * inner_num_ + j] -= 1;
		        ++count;
		      }
		    }
		  }
		  // Scale gradient
		  Dtype loss_weight = top[0]->cpu_diff()[0] /
		                      get_normalizer(normalization_, count)/
							  ensemble_num_;
		  caffe_scal(probs_[en]->count(), loss_weight, bottom_diff);
	  }
  }
  //compute diff of weight_loss to w1...wn
  for(int en=ensemble_num_;en<2*ensemble_num_;en++){
  	  if(propagate_down[en]){
  		  Dtype* bottom_diff = bottom[en]->mutable_cpu_diff();
  		  caffe_cpu_gemm(CblasNoTrans,CblasNoTrans,
  				num_out_,num_in_,num_out_,
				  (Dtype)1., K_[en-ensemble_num_]->cpu_data(), bottom[en]->cpu_data(),
				  (Dtype)0., bottom_diff);
  		  // Scale gradient
  		  Dtype loss_weight = lamda_ * top[0]->cpu_diff()[0]/ensemble_num_;
  		  caffe_scal(bottom[en]->count(), loss_weight, bottom_diff);
  	  }
  }

}

#ifdef CPU_ONLY
STUB_GPU(EnsembleSoftmaxLossLayer);
#endif

INSTANTIATE_CLASS(EnsembleSoftmaxLossLayer);
REGISTER_LAYER_CLASS(EnsembleSoftmaxLoss);

}  // namespace caffe
